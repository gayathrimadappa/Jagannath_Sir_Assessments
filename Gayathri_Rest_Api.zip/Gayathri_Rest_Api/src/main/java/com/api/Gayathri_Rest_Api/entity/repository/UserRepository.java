package com.api.Gayathri_Rest_Api.entity.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.api.Gayathri_Rest_Api.entity.User;

@Repository
public interface UserRepository extends  JpaRepository<User, Long> {

	User findByName(String name);
}
