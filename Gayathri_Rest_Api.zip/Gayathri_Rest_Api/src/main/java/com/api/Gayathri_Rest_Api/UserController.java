package com.api.Gayathri_Rest_Api;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.api.Gayathri_Rest_Api.entity.User;
import com.api.Gayathri_Rest_Api.entity.repository.UserRepository;

@RestController
public class UserController {

	@Autowired
	UserRepository userRepository;

	@GetMapping("Users")
	public List<User> getAllUsers() {

		List<User> userList = userRepository.findAll();

		// List<User> userList = new ArrayList<>();

		/*
		 * User u1 = new User(1l, "Gayathri Madappa", 22, "Female", "Bangalore"); User
		 * u2 = new User(2l, "Sampath Kumar", 23, "Male", "Bangalore"); User u3 = new
		 * User(3l, "Pramod", 24, "Male", "Yellahanka"); User u4 = new User(4l,
		 * "Gayatri", 22, "Female", "Koppala"); User u5 = new User(5l, "Ankith Gowda",
		 * 23, "Male", "Bangalore"); User u6 = new User(6l, "Pravallika", 22, "Female",
		 * "Hyderabad");
		 * 
		 * userList.add(u1); userList.add(u2); userList.add(u3); userList.add(u4);
		 * userList.add(u5); userList.add(u6);
		 */

		for (User val : userList)
			System.out.println(val);

		return userList;

	}

	@PostMapping("Users")
	public User createUser(@RequestBody User user) {
		User dbUser = userRepository.save(user);
		return dbUser;
	}

	@PutMapping("Users/id")
	public User updateUser(@RequestBody User user, @PathVariable("id") Long id) {
		User updateUserData = userRepository.getById(id);

		updateUserData.setName(user.getName());
		updateUserData.setAge(user.getAge());
		updateUserData.setGender(user.getGender());
		updateUserData.setCity(user.getCity());
		updateUserData.setRole(user.getRole());

		User dbUser = userRepository.save(updateUserData);

		return dbUser;
	}
	
    @DeleteMapping("/Users/{id}") 
    public String deleteUser(@PathVariable("id") Long id) 
    { 
    	User dbUser = userRepository.getById(id);
    	userRepository.delete(dbUser); 
    	return "User Deleted Successfully!";
    }

}
