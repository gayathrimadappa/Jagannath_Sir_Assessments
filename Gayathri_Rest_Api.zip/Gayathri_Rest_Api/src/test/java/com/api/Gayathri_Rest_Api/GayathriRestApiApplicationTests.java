package com.api.Gayathri_Rest_Api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GayathriRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
